shinyServer(function(input, output) {
  
  output$cosinus <- renderPlot({
    x<-seq(input$Pasek[[1]],input$Pasek[[2]],length.out = 1000)
    y<- cos(x)
    if (input$Pudelko) {
      plot(x, y, type='l', col='red')
    } else {
      plot(x, y, type='l', col='green')
    } 
  })
  
})
