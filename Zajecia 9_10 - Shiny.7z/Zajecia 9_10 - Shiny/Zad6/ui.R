shinyUI(fluidPage(
  
  titlePanel("Wykres funkcji cosinus"),
  
  sidebarLayout(
    sidebarPanel(
      checkboxInput("Pudelko", label = "Zmien kolor wykresu", value = FALSE ),
      sliderInput("Pasek", label = "Zakres wartości", value=c(1,2), min=-10, max=10)
    ),
    
    mainPanel(
      plotOutput("cosinus")
    )
  )
))