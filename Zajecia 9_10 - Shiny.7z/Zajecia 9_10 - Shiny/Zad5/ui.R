shinyUI(fluidPage(
  
  titlePanel("Przybliżenia Taylora funkcji exp(x)"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput("stopien", label="Wybierz liczbe naturalna od 1 do 10", choices=c("1"=1,"2"=2,"3"=3, "4"=4,
                                                                                    "5"=5, "6"=6, "7"=7,
                                                                                    "8"=8, "9"=9, "10"=10), selected=1),
      sliderInput("przedzial", label="Wybierz przedział argumentów", min=-10, max=10, value=0.5, step=1),
      radioButtons("kolor", label="Wybierz kolor", choices = c("Pomaranczowy" = 'orange', "Czerwony" = 'red', 
                                                               "Zielony" = 'green'), selected=2),
      numericInput("argument", label="Wybierz wielkosc probki", value=1, min=-10, max=10, step=1),
      textInput("autor", label="wprowadz imie", value="A")
    ),
    
    mainPanel(
      plotOutput("wykres"),
      textOutput("wynikiem"),
      textOutput("autorem")
    )
  )
))