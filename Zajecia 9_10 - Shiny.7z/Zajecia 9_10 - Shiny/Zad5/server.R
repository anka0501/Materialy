shinyServer(function(input, output) {
  
  output$wykres<-renderPlot({
    x<-input$przedzial[[1]]:input$przedzial[[2]] 
    x2<-numeric(length(x))+1
    for (i in 1:input$stopien){
      x2<-x2+x^(i)/factorial(i)
    }
    plot(x,exp(x), type='line')
    lines(x,x2,col=input$kolor)
  })
  output$wynikiem<-renderText({
    obl<-exp(input$argument)-(1+sum((input$argument)^(1:input$stopien)/(factorial(1:input$stopien)))
                              return(paste("Różnica wartości w punkcie x=", input$argument, "jest ", obl))
  })
    output$autorem<-renderText({paste("Autorem jest: ", input$autor)})
    
})