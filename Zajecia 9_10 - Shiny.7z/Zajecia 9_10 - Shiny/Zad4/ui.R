shinyUI(fluidPage(
  
  titlePanel("Wykres funkcji sinus(beta * x - alfa)"),
  
  sidebarLayout(
    sidebarPanel(
      
      helpText("Wybierz które parametry chcesz edytować a następnie ustal ich wartość. W przypadku braku edycji przyjmowane są wartości domyślne parametrów równe 1"),
      sliderInput("alpha", label="Wybierz przesuniecie argumentów", min=-10, max=10, value=1, step=1),
      sliderInput("beta", label="Wybierz mnoznik argumentów", min=-10, max=10, value=1, step=1)
      ,checkboxInput("alpha_check", label = "Przesuwanie argumentu", value = FALSE ),
      checkboxInput("beta_check", label = "Przesuwanie argumentu", value = FALSE )
    ),
    
    mainPanel(
      plotOutput("sinus")
    )
  )
))