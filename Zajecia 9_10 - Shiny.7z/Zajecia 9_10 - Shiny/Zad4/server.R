shinyServer(function(input, output) {
  
  output$sinus <- renderPlot({
    x<-seq(-pi/2,2*pi,length.out = 1000)
    if (input$alpha_check & input$beta_check) {
      y<- sin(input$beta * x - input$alpha)
    } else if (input$alpha_check & !input$beta_check){
      y<- sin(x - input$alpha)
    } else if (!input$alpha_check & input$beta_check){
      y<- sin(input$beta * x)
    } else {
      y<- sin(x)
    }
    plot(x, y, type='l')
  })
  
})