###########################################################
#             Zaawansowane programowanie w R              #
#              niestandardowa ewaluacja kodu              #
#                      Zajęcia 11                         #
#             Piotr Ćwiakowski, Piotr Wójcik              #
###########################################################    

# Zajęcia 7 poświęcimy niestandardowej ewaluacji w R. Zauważmy najpierw ciekawą 
# właściwość wielu funkcji w R. Przykładowo w dplyr: 

library(dplyr)
filter(mtcars,  mpg<20)

# Funkcja filter musi dokonać ewaluacji wyrażenia 'mpg<20' w środowisku mtcars,
# wykonując operację:

mtcars[mtcars$mpg<20,]

# Tzn., że musi pobrać informację o tym, w jakim środowisku znajduje się mpg i 
# zamiast globalenv()$mpg wykonać mtcars$mpg.


# Drugim dobrym przykładem jest poniższe wywołanie funkcji plot:

x <- seq(1,10, length.out = 1000)
sinx <- sin(x)

plot(x, sinx, type = 'l')

# Można zadać przytomne pytanie: jak kod programu wiedział, żeby nazwać oś oX 'x',
# a oY 'sinx'? Żeby to zrobić, musiał znać wzór wywołania obiektów, które były 
# argumentami funkcji, a nie tylko wartości które zostały zwrócone. Nie jest to jednak
# takie oczywiste. Przecież nie potrafimy tak łatwo zwrócić nazwy obiektu - 
# potrafimy zwrócić elementy listy funkcją names(lista) ale wciąż musimy podać 
# nazwę obiektu.

# OK. Zrozumienie dlaczego to działa wymaga poznania kilku narzędzi do 
# metaprogramowania czyli odwoływania się do skryptu bez jego wcześniejszej ewaluacji.

# 1. 

# W budowaniu wyrażeń potrzebne są dwie funkcje: substitute() i eval()

# 1.1. substitute() i eval()
# Funkcja substitute zwraca nieewaluowane wcześniej wyrażenie klasy call. Jest ono niezbędne
# do budowania funkcji w niestandardowej ewaluacji. Zauważmy, że wyrażenia są podawane
# bez cudzysłowia.

f <- function(x) {
  substitute(x)
}
f(1:10)


# Przykład:
zmienna <- 20
zmienna2 <- 3

f(zmienna)
f(zmienna*zmienna2)

# Funkcja substitute funkcjonuje w ten sposób, ponieważ zwraca specjalny typ obiektu.
# Zawiera on informacje o środowisku w którym znajduje się wyrażenie (expression) i
# i samo wyrażenie. Są różne klasy wyrażeń. W naszym przypadku występuje  typ 'call'.


class(f(1:10))
obiekt <- f(1:10)

obiekt[[1]]
obiekt[[2]]
obiekt[[3]]
obiekt[[4]]

# Gdzie się pojawia? Np. w regresji liniowej. Zauważmy:

x1 <- 1:1000
y1 <- 0.5*x1 + rnorm(1000) 

df <- data.frame(x1,y1)

lm(y1 ~ x1, data = df)

lm(df$y1 ~ df$x1)

lm(df[,2] ~ df[,1])

# funkcja substitute bardzo często występuje z funkcją deparse. Zamienia ona wyrażenie
# w tekst, pozwalając w ten sposób na nadawanie domyślnych nazw.

f <- function(x) {
   deparse(substitute(x))
}
f(1:10)

# I wyjaśniła się zagadka. Już wiemy jak funkcja plot() nadaje domyślne nazwy osi. 
# Na pewnym etapie pobiera do funkcji substitute nazwy obiektów podawanych do x i y
# i następnie zamienia je funkcją deparse na tekst. W ostatnim kroku przypisuje tekst 
# do osi. W ten sposób unikamy pisania cudzysłowiów za każdym razem. Np. przypisaniu
# nazw bibliotek:
library(ggplot2)
library('ggplot2')

# Albo własnie w wspomnianej przed chwilą funkcji data.frame:
df <- data.frame(x1,y1)

# Algorytm sam wie, jakie nadać nazwy kolumnom. Teraz rozwiążmy drugą zagadkę: 
# Jak właściwie działa dplyr::filter()? Jest to możliwe dzięki połączeniu sił 
# przez dwie funkcje - eval() i qoute(). 

# 1.2. Funkcje eval() i quote()

# Funkcja qoute działa bardzo podobnie jak substitue (jest nawet dostępna w tym
# samym pliku pomocy), ale w przeciwieństwie do niej zwraca proste wyrażenie 
# zamiast skomplikowanej listy jak substitue. Jej podstawowym zadaniem jest zapobiegać
# przedwczesnej ewaluacji kodu. Przykladowo:

quote(1:10)
quote(a - sqrt(b))

# Aby przeprowadzić ewaluację kodu i zwrócić wynik do konsoli bądź innego obiektu,
# potrzebujemy funkcję eval(). 

eval(quote(1:10))
eval(a - sqrt(b))

# eval() pozwala wskazać środowisko, w którym ma być wykonana operacja. Tym środo-
# wiskiem może być na przykład:
rm(x1)
eval(quote(x1))
eval(quote(x1), df)

# Voila! Teraz już wiemy jak działa funkcja filter, to jest coś w stylu:
eval(quote(mpg<20), mtcars)

# A więc:
mtcars[eval(quote(mpg<20), mtcars), ]

# I teraz prosta funkcja (prawdziwa pozwala na nieokreśloną liczbę argumentów,
# więc jest nieco bardziej skomplikowana):

proste_filtrowanie <- function(data, x){
  wyrazenie <- substitute(x)
  ew_wyrazenie <- eval(wyrazenie, data) 
  data[ew_wyrazenie, ]
}

proste_filtrowanie(mtcars, mpg < 20)

# W funkcji używamy quote zamiast substitue, ponieważ substitute przechwytuje 
# właściwe wyrażenie, podczas gdy quote w ramach funkcji łapie nazwę argumentu 
# funkcji. Zauważmy:

f <- function(x) {
   list(quote(x), substitute(x))
}

f(x = disp < 150)

#################################
# 1.3. Problemy z zakresem nazw

# Zauważmy, że w naszej funkcji:

x <- 20
y <- 20
wyrazenie <- 20

proste_filtrowanie(mtcars, mpg < x)
proste_filtrowanie(mtcars, mpg < y)
proste_filtrowanie(mtcars, mpg < wyrazenie)

# Problemy w odwołaniach do x i wyrazenie polegają na tym, że eval szuka obiektow
# najpierw w data.frame'ie a później wewnątrz funkcji subset() - co nie jest po- 
# żądane. Żeby temu zapobiec, w funkcji eval() ustawiamy trzeci argument, odpowie-
# dzialny za określenie środowiska nadrzędnego - ustawiamy parent.frame(), czyli
# środowisko w którym została wywołana funkcja proste_filtrowanie.

proste_filtrowanie <- function(data, x){
  wyrazenie <- substitute(x)
  ew_wyrazenie <- eval(wyrazenie, data, parent.frame()) 
  data[ew_wyrazenie, ]
}

# Teraz działa:
proste_filtrowanie(mtcars, mpg < x)

###################################
# 1.4. Wyrażenia (Expressions)



#######################################################
# 1.5. Standardowa ewaluacja funkcji napisanych w NSE

# http://www.carlboettiger.info/2015/02/06/fun-standardizing-non-standard-evaluation.html






########################################################
# Ćwiczenia 

# 1. Coś z Hadleya


# 2. Coś z Hadleya


# 3. Napisanie funkcji subset 