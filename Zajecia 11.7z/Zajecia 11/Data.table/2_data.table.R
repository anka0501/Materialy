###########################################################
#             Zaawansowane programowanie w R              #
#                   pakiet data.table                     #
#                      Zajęcia 11                         #
#             Piotr Ćwiakowski, Piotr Wójcik              #
########################################################### 

# install.packages("data.table")

library(data.table)
library(tidyr)

setwd('C:\\Users\\ag387890\\Desktop\\Zajecia 11\\Data.table')

f <- fread("footballers.csv", dec = ",")

k1 <- function() {
  rm(f, envir = .GlobalEnv)
  assign("f", fread("~/Desktop/Zajecia 11/Data.table/footballers.csv", dec = ","), 
         envir = .GlobalEnv)
}


# k1 <- function() {
#   rm(f, envir = .GlobalEnv)
#   assign("f", fread("~/Desktop/R/materialy/Lekcja 2 - ggplot2/Dane 2/footballers.csv", dec = ","), 
#          envir = .GlobalEnv)
# }

# market_value – szacowana wartość napastnika na rynku transferowym według portalu www.transfermarket.de,
# age – zmienna oznaczająca wiek napastnika,
# height – wzrost napastnika podany w cm,
# weight – waga napastnika podaną w kg,
# goals_CL – ilość bramek zdobytych przez danego napastnika w ciągu ostatnich pięciu pełnych sezonów  w rozgrywkach europejskiej Ligi Mistrzów (Champions League),
# goals_UEFA – ilość bramek zdobytych przez danego napastnika w ciągu ostatnich pięciu pełnych sezonów w rozgrywkach Ligi Europejskiej (European League) wcześniej zwanej rozgrywkami Pucharem UEFA (UEFA Cup),
# goals_cup – ilość bramek zdobytych przez danego napastnika w ciągu ostatnich pięciu pełnych sezonów w rozgrywkach pucharów krajowych (Hiszpania: Copa del Rey; Anglia: F.A. Cup, Włochy: Copa Italia; Niemcy:  Deutscher Fußball Bund Pokal; Francja: Coupe de France de football),
# goals_top5l  – ilość bramek zdobytych przez danego napastnika w ciągu ostatnich pięciu pełnych sezonów w rozgrywkach pięciu najlepszych (wg UEFA) lig europejskich (Angielska, Hiszpańska, Włoska, Niemiecka, Francuska),
# goals_rest – ilość bramek zdobytych przez danego napastnika w ciągu ostatnich pięciu pełnych sezonów w rozgrywkach pozostałych lig światowych,
# goals_nat – ilość bramek zdobytych przez danego napastnika w ciągu całej kariery w rozgrywkach międzynarodowych (kadra narodowa), zarówno w meczach towarzyskich jak i oficjalnych spotkaniach,
# app_nat – ilość występów (zarówno w pierwszym składzie jak i po wejściu z ławki rezerwowych) w kadrze narodowej danego napastnika w ciągu całej kariery, 
# games_start – ilość rozegranych spotkań, które dany napastnik zaczynał w wyjściowym (pierwszym) składzie, dotycząca ostatnich pięciu sezonów,
# subs – zmienna określająca ilość spotkań, w których dany napastnik wchodził na boisko jako rezerwowy (nie był elementem pierwszego, wyjściowego składu), dotycząca ostatnich pięciu sezonów,
# shots_tot – ilość wszystkich strzałów (celnych i niecelnych) oddanych przez danego napastnika w ciągu ostatnich pięciu sezonów,
# shots_on_gs – ilość celnych strzałów (piłka po uderzeniu zmierzała w światło bramki) oddanych przez danego napastnika w ciągu ostatnich pięciu sezonów,
# top_spa – 1 dla napastnika, który w ciągu ostatnich pięciu sezonów zdobył Trofeo Pichichi przyznawane corocznie dla najlepszego strzelca pierwszej ligi hiszpańskiej (Primera División),
# top_ita – 1 dla napastnika, który w ciągu ostatnich pięciu sezonów zdobył trofeum przyznawane corocznie dla najlepszego strzelca pierwszej ligi włoskiej (Serie A),
# top_eng – 1 dla napastnika, który w ciągu ostatnich pięciu sezonów zdobył trofeum przyznawane corocznie dla najlepszego strzelca pierwszej ligi angielskiej (Premier League),
# top_ger – 1 dla napastnika, który w ciągu ostatnich pięciu sezonów zdobył trofeum przyznawane corocznie dla najlepszego strzelca pierwszej ligi niemieckiej (Bundesliga),
# top_fra – 1 dla napastnika, który w ciągu ostatnich pięciu sezonów zdobył trofeum przyznawane corocznie dla najlepszego strzelca pierwszej ligi francuskiej (Ligue 1),
# rank – miejsce w rankingu Castrol danego napastnika,
# popularity –popularność danego napastnika mierzoną w milionach wyświetleń w wyszukiwarce google.com.
# name - nazwa piłkarza

head(f) #obejrzyjmy kilka pierwszych obserwacji
str(f) #obejrzyjmy strukturę bazy (typy zmiennych)
names(f) #nazwy zmiennych

### 1. Operacje na kolumnach

## 1.1 Wybór zmiennych do analizy

#wybranie kolumn name, weight, height
f[, .(name, weight, height)]

# to samo tylko z zapisaniem wyników do zewnętrznego obiektu
a <- f[, .(name, weight, height)]

# usunięcie kolumn name, weight, height

b <- f[, .SD, .SDcols = !grepl(pattern = "name|weight|height", names(f))]

# lub
# uwaga 3 poniższe - "by reference" - usuwa kolumny i trzeba od nowa wczytać bazę
# zawsze dla operatora `:=` oraz :=

f[, `:=`(name = NULL, weight = NULL, height = NULL)] 
k1()

# lub
f[, c("name", "weight", "height") := NULL]
k1()

# lub
kolDoUs2 <- c("name", "weight", "height")

f[, (kolDoUs2) := NULL]
k1()

# zauważmy, że kolDoUs jest w nawiasie () - gdyby go nie było,
# usunęlibyśmy kolumnę o nazwie "kolDoUs"

# choć wygodnie jest też tak:
f$height <- NULL

## 1.2 Zmiana nazw zmiennych

# setnames(baza, stare, nowe)
setnames(f, c("goals_CL", "goals_UEFA"), c("goals_cl", "goals_uefa"))

### 2. Operacje na data.table

#Wybór z bazy f szeregu zmiennych i zapisanie do d
d <- f[, .(name, goals_cl, goals_uefa, goals_top5l, goals_rest, goals_nat)]

# Podobnie ale za pomocą funkcji %grepl - krócej.
f[, .SD, .SDcols = grepl("goals", names(f))]

# Wybranie zmiennych kończących się na frazę "ght"
f[, .SD, .SDcols = grepl("ght$", names(f))]

# Wybranie zmiennych mających w nazwie podaną frazę
f[, .SD, .SDcols = grepl("als_", names(f))]

# Wybranie kolumn które są u nas na liście.
f[, .SD, .SDcols = grepl("goals_cl|goals_uefa|goals_PL", names(f))]

# Wybranie kolumn zaczynających się od danej frazy i zmiennej name
f[, .SD, .SDcols = grepl("^goals_", names(f)), by = name] -> fa

# 3. Filtrowanie bazy po wierszach

## Argument `i`

# Wybór osób  w wieku od 21 do 25
f[age > 21 & age < 25]

# Wybierzmy osoby o danym wieku i wzroście
f[age == 23 & height <= 180]

# Wybierzmy osoby w wieku 20 i 23 lata
f[age == 20 | age == 23]

# Przypuśćmy, że chcemy szukać wierszy dla piłkarzy:
trzech <- f[sample(1:.N, 3), name]

f[name %in% trzech]

# A jak będzie ich więcej?
siedmiu <- f[sample(1:.N, 7), name]

f[name %in% siedmiu]

## 3.2. Wybieranie unikalnych wartości

f[, .(liczba = .N), by = age]

## 3.3 Sortowanie obserwacji
f[order(age, decreasing=T)][, .(age)][,.(liczba=.N), by=age]


head(f[, .(age)][order(age, decreasing = T)], 10)

# ustalenie klucza dla danej kolumny automatycznie 
# sortuje "by reference" całą bazę wg tej kolumny
setkey(f, age)

head(f[, .(age)], 10)

head(f, 10)
k1()

## 3.4. Losowanie operacji ze zbioru

f[sample(.N, 3)]

### 4.  Zamiana struktury bazy 

# Dane typu wide:
# w wierszach obserwacje w kolumnach zmienne
# Dane typu long: 
# 3 kolumny - indeks, kolumna z nazwami charakterystyk, kolumna z wartościami
# w wierszach kombinacje id obserwacji, nazwa zmiennej i jej wartość

## 4.1. Funkcja melt() - z wide na long
# Funkcja melt ma 5 argumenty:
# data - baza danych
# id - które kolumny zostają
# measure - nazwy zmiennych które mają być przekształcone
# variable.name - nazwa nowej zmiennej zawierającej przekształcone zmienne z argumentu measure
# value.name - nazwa nowej zmiennej z wartościami

# Przykłady skonstruowano w oparciu o ostatnią bazę z poprzedniego rozdziału
fm <- melt(fa, id = c("name"), 
           measure = c("goals_CL", "goals_UEFA", "goals_top5l", "goals_rest", "goals_nat", "goals_cups"), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

# lub
fm <- melt(fa, id = 1, 
           measure = c(2:7), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

# lub 
fm <- melt(fa, id = 1, 
           measure = patterns("^goals_"), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

# dołóżmy filtrowanie zmiennych
fm <- melt(f[age > 21 & age < 25], id = "name", 
           measure = patterns("^goals_"), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

## 4.2 Funkcja dcast() z long na wide

fw <- dcast(fm, name ~ Rozgrywki, value.var = "liczba.bramek1")
head(fw)

## 4.3 Scalanie kolumn funkcja unite()

# data.table nie posiada specjalnej funkcji do łączenia kolumn

unite(data = f[, .(name, age)], col = "name_age", c(1 , 2), sep = "_")

## 4.4 Rozscalanie kolumn funkcja seperate()

#jw

### 5. Tworzenie nowych zmiennych 

# przypomnienie `:=` - by reference
f[, wiek2 := age^2]
head(f)
k1()

f[, `:=`(suma = sum(goals_nat))]
head(f)
k1()

### 6. Grupowanie i podsumowanie 

## 6.1 Podsumowanie

f[, 
  .(sr.wartosc = mean(market_value),
    max.wartosc = max(market_value),
    min.wartosc = min(market_value),
    sd.wartosc = sd(market_value),
    var.wartosc = var(market_value))
  ]



## 6.2 grupowanie

f[, 
  .(sr.wartosc = mean(market_value),
    max.wartosc = max(market_value),
    min.wartosc = min(market_value),
    sd.wartosc = sd(market_value),
    var.wartosc = var(market_value)),
    by = .(cut(age, 5), popularity > mean(popularity))][order(cut, popularity)]

## 6.3. Zliczanie obserwacji w obrębie grup

f[, .N, by = cut(age, 5)]

f[, .(liczba = .N), by = cut(age,5)]

### 7. Operacje na bazach danych 

## 7.1. Łączenie baz po wspólnym kluczu

# Przygotujmy małe, przykładowe bazy do pracy.
a <- f[1:8, .(name, weight)]
b <- f[4:12, .(name, height)]

merge(a, b, by = "name", all = T)
merge(b, a, by = "name", all = T)

# lub
setkey(a, name)
setkey(b, name)

a[b]
b[a]

# dodajmy argument nomatch = 0 - usuwa obserwacje z NA
a[b, nomatch = 0]
b[a, nomatch = 0]

# lub
merge(a, b, by = "name")
merge(b, a, by = "name")

a[b, nomatch = 0][, .(name, weight)]
b[a, nomatch = 0][, .(name, height)]

a[b][is.na(weight), .(name, height)]
b[a][is.na(height), .(name, weight)]

## 7.3 Porównywanie zakresów w dwóch bazach

# Stwórzmy nowe zmienne do analizy:
a <- f[1:8, .(name, weight)]
b <- f[4:12, .(name, weight)]

# Część wspólna zbiorów
setkey(a, name)
setkey(b, name)

a[b, nomatch = 0]



# data.table tutorial, cheet sheet amazon, faq data table


