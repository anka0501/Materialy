###########################################################
#          Przetwarzanie danych w data.table              #
###########################################################

# Biblioteki
# install.packages('data.table')
# install.packages('tidyr')
# install.packages('bit64')
# install.packages(nycfligths13)
# install.packages('dplyr')

library(data.table)
library(dplyr)
library(tidyr)
library(bit64)
library(nycflights13)

# Ustawienie ścieżki dostępu do danych
setwd('/Users/piotrcwiakowski/Dropbox/Szkolenia/10. Programowanie/1. Wprowadzenie/0_Dane')


# Wyczyszczenie pamięci
rm(list=ls())

# Funkcje
k1 <- function() {
  rm(f, envir = .GlobalEnv)
  assign("f", fread("footballers.csv", dec = "."), 
         envir = .GlobalEnv)
}

# Funkcje
k2 <- function() {
  rm(a, envir = .GlobalEnv)
  assign("a", fread("czas.wolny.csv", dec = ","), 
         envir = .GlobalEnv)
}

# Fligths
data(flight)

f[,!c('name','weight','height')]


k1()
k2()
# Importowanie danych z pliku

# standardowa funkcja:
system.time( p <- read.csv("czas.wolny.csv",sep=",",header=T) )
class(p)
print(object.size(p), units = "Mb")
p

# data.table: (znaczniej szybciej!)
system.time( a <-fread("czas.wolny.csv",sep=",",header=T) ) # funkcja fread() - od "fast read"
class(a) # data.table i data.frame
print(object.size(a), units = "Mb") # trochę więcej..
a

# Można również użyć funkcji generycznej:
p <- as.data.table(p)
class(p)

names(a); rm(p)

# Spróbujmy jeszcze z większą bazą:
data("flights")
write.csv(flights,'flights.csv')

# standardowa funkcja:
system.time( p <- read.csv("flights.csv",sep=",",header=T) )
class(p)
print(object.size(p), units = "Mb")
p

# data.table: (znaczniej szybciej!)
system.time( a <-fread("flights.csv",sep=",",header=T) ) # funkcja fread() - od "fast read"
class(a) # data.table i data.frame
print(object.size(a), units = "Mb") # trochę więcej..
a

# Importowanie drugiego zbioru
f <- fread("footballers.csv", dec = ",")

# Ogólna forma odwoływania się do obektu data.table:
# DT[i, j, by] “Weź obiekt DT, wybierz wiersze używając argumentu i, następnie wykonaj operacje
# zaproponowane w argumenciej w podgrupach zdefiniowane przez argument by”

# 1. Uwagi ogólne:
# 1. Wszystkie argumenty są opcjonalne
# 2. Do zmiennych odwołujemy się bez cudzysłowów
# 3. Przy modyfikacji bazy można uniknąć przypisywania "<-" za pomocą operatora :=
# 4. Obiekt data.table jest również data frame'em, dlatego będzie kompatibilny ze 
# wszystkimi funkcjami używającymi df.

#######################################
# 2. Wybieranie wierszy (argument i) ##
#######################################

# Za pomocą kolejnych numerów w bazie:
a[2:3,]

# Za pomocą wyrażeń logicznych
a[wiek==65] # zwróć uwagę na numerację wierszy!
a

# Za pomocą wektorów
a[rasa %in% c('czarna','inna')]
a

# Wybór osób  w wieku od 21 do 25
f[age > 21 & age < 25]

# Wybierzmy osoby o danym wieku i wzroście
f[age == 23 & height <= 180]

# Wybierzmy osoby w wieku 20 i 23 lata
f[age == 20 | age == 23]

# Przypuśćmy, że chcemy szukać wierszy dla piłkarzy:
trzech <- f[sample(1:.N, 3), name]

f[name %in% trzech]

# A jak będzie ich więcej?
siedmiu <- f[sample(1:.N, 7), name]

f[name %in% siedmiu]

##########################################
# 3. Działania na kolumnach (argument j) #
##########################################

# 3.1. Wybór kolumny

# Wybranie kolumny name
f[,name]

# .() jest aliasem do polecenia list(). Jeśli .(), zwracany jest obiekt data.table. 
# W przeciwnym przypadku zwracany jest wektor.

#wybranie kolumn name, weight, height
f[, .(name, weight, height)]

# Zapiszmy do zewnętrznego obiektu:
baza <- f[, .(name, weight, height)]

# wybranie kolumn w inny sposób
f[,c('name','weight','height')]

# Można też odwoływać się tradycyjnie
f$age

# 3.2. Usuwanie zmiennych

# to samo tylko z zapisaniem wyników do zewnętrznego obiektu
a <- f[, .(name, weight, height)]

# usunięcie kolumn name, weight, height
b <- f[, .SD, .SDcols = !grepl(pattern = "name|weight|height", names(f))]

# lub
f[,!c('name','weight','height')]
f[,-c('name','weight','height')]


# lub
# uwaga 3 poniższe - "by reference" - usuwa kolumny i trzeba od nowa wczytać bazę
# zawsze dla operatora `:=` oraz :=

# f[, `:=`(name = NULL, weight = NULL, height = NULL)] 
k1()
# lub
# f[, c("name", "weight", "height") := NULL]
k1()

# lub
# do_usuniecia <- c("name", "weight", "height")
k1()
f[, (do_usuniecia) := NULL]
k1()

# zauważmy, że do_usuniecia jest w nawiasie () - gdyby go nie było,
# usunęlibyśmy kolumnę o nazwie "kolDoUs"

# choć wygodnie jest też tak:
f$height <- NULL


# 3.3. Wybór większej ilości kolumn

#Wybór z bazy f szeregu zmiennych i zapisanie do d
d <- f[, .(name, goals_cl, goals_uefa, goals_top5l, goals_rest, goals_nat)]

# Podobnie ale za pomocą funkcji %grepl - krócej.
f[, .SD, .SDcols = grepl("goals", names(f))]

# Wybranie zmiennych kończących się na frazę "ght"
f[, .SD, .SDcols = grepl("ght$", names(f))]

# Wybranie zmiennych mających w nazwie podaną frazę
f[, .SD, .SDcols = grepl("als_", names(f))]

# Wybranie kolumn które są u nas na liście.
f[, .SD, .SDcols = grepl("goals_cl|goals_uefa|goals_PL", names(f))]

# Wybranie kolumn zaczynających się od danej frazy i zmiennej name
f[, .SD, .SDcols = grepl("^goals_", names(f)), by = name] -> fa
f[, .SD, .SDcols = grepl("^goals_", names(f)), by = .(name,height)] -> fa1


# 3.3.1. Operacje na kolumnach

f[,.(lacznie=goals_CL+goals_UEFA)]

# Ile osób zdobyło więcej bramek niż 5?
f[,.(lacznie=sum(goals_CL+goals_UEFA>5))]

# Można też...
f[(goals_CL+goals_UEFA)>5,.N]

## 3.4. Wybieranie unikalnych wartości

f[, .(liczba = .N), by = age]

## 3.5. Sortowanie obserwacji

head(f[, .(age)][order(age, decreasing = T)], 100)

# ustalenie klucza dla danej kolumny automatycznie 
# sortuje "by reference" całą bazę wg tej kolumny
setkey(f, age)

head(f[, .(age)], 10)

head(f, 10)
k1()

# 3.6. Zmiana nazw zmiennych

# setnames(baza, stare, nowe)
setnames(f, c("goals_CL", "goals_UEFA"), c("goals_cl", "goals_uefa"))

##################################
### 4.  Zamiana struktury bazy ###
##################################

# Dane typu wide:
# w wierszach obserwacje w kolumnach zmienne
# Dane typu long: 
# 3 kolumny - indeks, kolumna z nazwami charakterystyk, kolumna z wartościami
# w wierszach kombinacje id obserwacji, nazwa zmiennej i jej wartość

## 4.1. Funkcja melt() - z wide na long
# Funkcja melt ma 5 argumenty:
# data - baza danych
# id - które kolumny zostają
# measure - nazwy zmiennych które mają być przekształcone
# variable.name - nazwa nowej zmiennej zawierającej przekształcone zmienne z argumentu measure
# value.name - nazwa nowej zmiennej z wartościami

# Używamy bazy fa
fm <- melt(fa, id = c("name"), 
           measure = c("goals_CL", "goals_UEFA", "goals_top5l", "goals_rest", "goals_nat", "goals_cups"), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

# lub
fm <- melt(fa, id = 1, 
           measure = c(2:7), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

# lub 
fm <- melt(fa, id = 1, 
           measure = patterns("^goals_"), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

# dołóżmy filtrowanie zmiennych
fm <- melt(f[age > 21 & age < 25], id = "name", 
           measure = patterns("^goals_"), 
           variable.name = "Rozgrywki", value.name = "liczba.bramek")

## 4.2 Funkcja dcast() z long na wide

fw <- dcast(fm, name ~ Rozgrywki, value.var = "liczba.bramek")
head(fw)

#####################################
### 5. Tworzenie nowych zmiennych ###
#####################################

# przypomnienie `:=` - by reference
f[, wiek2 := age^2]
head(f)
k1()

f[, `:=`(suma = sum(goals_nat))]
head(f)
k1()

####################################
### 6. Grupowanie i podsumowanie ###
####################################

## 6.1 Podsumowanie

f[, 
  .(sr.wartosc = mean(market_value),
    max.wartosc = max(market_value),
    min.wartosc = min(market_value),
    sd.wartosc = sd(market_value),
    var.wartosc = var(market_value))
  ]

## 6.2 grupowanie

f[, 
  .(sr.wartosc = mean(market_value),
    max.wartosc = max(market_value),
    min.wartosc = min(market_value),
    sd.wartosc = sd(market_value),
    var.wartosc = var(market_value)),
  by = .(cut(age, 5), popularity > mean(popularity))][order(cut, popularity)]

## 6.3. Zliczanie obserwacji w obrębie grup

f[, .N, by = cut(age, 5)]

f[, .(liczba = .N), by = cut(age,5)]

####################################
### 7. Operacje na bazach danych ###
####################################


## 7.1. Łączenie baz po wspólnym kluczu

# Przygotujmy małe, przykładowe bazy do pracy.
a <- f[1:8, .(name, weight)]
b <- f[4:12, .(name, height)]

merge(a, b, by = "name", all = T)
merge(b, a, by = "name", all = T)

# lub
setkey(a, name)
setkey(b, name)

a[b]
b[a]

# dodajmy argument nomatch = 0 - usuwa obserwacje z NA
a[b, nomatch = 0]
b[a, nomatch = 0]

# lub
merge(a, b, by = "name")
merge(b, a, by = "name")

a[b, nomatch = 0][, .(name, weight)]
b[a, nomatch = 0][, .(name, height)]

a[b][is.na(weight), .(name, height)]
b[a][is.na(height), .(name, weight)]

##############################
###     Dziękuję za uwagę! ###
##############################