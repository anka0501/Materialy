###########################################################
#             Zaawansowane programowanie w R              #
#          Zarządzanie środowiskiem i debugging           #
#                      Zajęcia 11                         #
#             Piotr Ćwiakowski, Piotr Wójcik              #
###########################################################    

# 1. Zarządzanie środowiskiem w programie R.
# Na podstawie: http://adv-r.had.co.nz/Environments.html
# Środowisko w R (environment) służy do wiązania obiektów (nazw) z konkretnymi
# wartościami. Spróbujmy:

# Komendą new.env() tworzymy nowe środowisko:
srod <- new.env()

# Następnie nowe obiekty wewnątrz środowiska tworzymy jak elementy listy:
srod$m <- TRUE
srod$n <- "wyraz"
srod$o <- 2.3
srod$p <- 1:3 

ls(srod)

# Przyjrzyjmy się teraz środowisku:
View(srod)

# Warto pamiętać że jest pewna różnica pomiędzy tymi wyrażeniami:
srod$m <- srod$n
srod$m <- 'wyraz'

# W pierwszym przyypadku m i n wskazują dokładnie ten sam obiekt w pamięci,
# W drugim m i n wskazują tą samą wartość ale zduplikowaną w pamięci. 

# Cechy środowiska:
# Środowisko zachowuje się jak lista, ale:
# * nazwy w środowisku są unikalne
# * nazwy są nieuszeregowane
# * każde środowisko ma środowisko nadrzędne (parent), za wyjątkiem środowiska pustego
# emptyenv()

# Przyjrzyjmy się kilku funkcjom odwołującym się do środowisk:
# Zwracają wskazenie do danego środowiska, co można wykorzystać w funkcjach 
# przyjmujących takie argumenty
globalenv() # środowisko globalne
baseenv() # środowisko pakietu base
environment() # środowisko bieżące (globalne + ostatni wgrany pakiet komendą library() lub require()
as.environment("package:stats")

# Funkcja search() zwraca wszystkie dostępne środowiska
search()

# Wszystkie pakiety są połączone hierarchiczne w tzw. "search path", przy czym
# .GlobalEnv jest najniżej, a package:base jest najogólniejsze i ogólniejsze jest
# tylko emptyenv()
# 
# 

parent.env(.GlobalEnv)
parent.env(as.environment('tools:rstudio'))
#...
parent.env(as.environment('package:base'))
parent.env(as.environment('R_EmptyEnv'))

# I jeszcze zwróćmy uwagę na srodowisko srod
parent.env(srod)

srod$m
# Możemy wylistować wszystkie obiekty znaną funkcją ls()
ls(srod)

# Możemy wykorzystać również opcję wylistywojace takze obiekty z kropka na poczatku:
srod$.test <- 1:10
ls(srod)
ls(srod, all.names = TRUE)

# Zwróćmy też uwagę na wariant funkcji str():
str(srod)
ls.str(srod)
ls.str(srod, all.names = TRUE)
# Odwołanie do obiektu w środowisku jest możliwe na trzy sposoby:
srod$m
srod[['m']]
get('m', envir = srod)

# Zauważmy:
m <- 5

get('m', envir = globalenv())
get('m', envir = srod)

# Argument odnoszący się do środowiska ma również funkcja rm()
rm("m", envir = globalenv())
ls(globalenv())
ls(srod)

# Możemy również pytać o zmienne:
exists("m", envir = srod)

library(ggplot2)

search()

exists("diamonds", envir = srod, inherits = T)
exists("diamonds", envir = srod, inherits = F)

# Do czego przydaje się wiedza o środowiskach?
# 1. Pozwala bardziej świadomie korzystać z programu R,
# 2. Pozwala zarządzać obiektami w dużych projektach informatycznych

# W programowaniu warto pamiętać o dwóch funkcjach
assign()
get()

# Pierwsza tworzy obiekt o zadanej nazwie w zadanym środowisku jako wynik działania innej funkcji:
assign('test', list(a =1, b = 1:10), envir = srod)
View(srod)
ls(srod)
assign('test', list(a =1, b = 1:10))
test <- list(a =1, b = 1:10)


for (i in 1:10){
  assign(paste0('test ',i), list(a =1, b = 1:10))
  
}
get('test', envir = srod)

# 2. Debugging

# Zacznijmy od napisania prostej funkcji, którą umieszczamy w osobnym skrypcie 
# R-owym. Kiedy otworzymy ten plik w osobnym oknie, możemy zauważyć, że na lewym
# marginesie pojawiła się czerwona kropka - tzw. 'breakingpoint'. Kiedy interpre
# tator natrafi na tą linię, zatrzyma działanie i otworzy środowisko debuggera,
# które pozwoli nam przechodzić kolejne wiersze krok po kroku. 
# 
# Spróbujmy odtworzyć tą sytuację. W tym celu musimy wczytać funkcję komendą 
# source (inaczej breakpointy nie będą działały):  
source('f1.R')

# Po wykonaniu skryptu w oknie po prawej pojawia się funkcja f1 - wydzimy koło
# jej nazwy czerwoną kropkę, która oznacza, że wewnątrz niej znajduje się breakpoint

# Wywołajmy teraz funkcję poprawnie:
library(ggplot2)
data(diamonds)
f1(diamonds)

# Włącza nam się debugger w RStudio. Zauważmy
# 1. W konsoli pojawiło się przed znakiem ">" wyrażenie Browser[N],
# 2. Nad konsolą pojawiły się ikony odwołujące się do funkcji debuggera:
#     a. Next [n] - wykonaj bieżącą linijkę kodu (skrót F10))
#     b. Step into function [s] - wykonanie kolejnej funkcji przez wkroczenie do środka kolejnej funkcji (jeśli skompilowana bajtowo to równorzędne do n)
#     c. Finish function/Loop[f] - wykonaj funkcję do końca bez względu na kolejne breakpoints.
#     d. Continue [c] - kontynuuj działanie funkcji aż do kolejnego punktu (skrót Shift+F5)
#     e. Stop [Q] - przerwij działanie funkcji i zakończ działanie debuggera (skrót Shift+F8)
# 3. Zauważmy, że zmieniło się środowisko - teraz pokazywane są bieżące wartości argumentów
# z wewnątrz funkcji.
# 4. Pojawiło się nowe okno Traceback - które pozwala wyśledzić źródła błędów i zaznaca breakpointy.
#  
#  
#  Włączenie debuggera następuje również gdy:
#  a. wewnątrz funkcji użyjemy komendy browser():

f1 <- function(dane){
  print('krok 1')
  browser()
  model <- lm(price ~ ., data = dane)
  print('krok 1')
  print('krok 2')
  if(TRUE){
    w <- c(1,2)
    y <- 'a'
    z <- 'f'
  }
  summary(model)
}  

f1(diamonds)

# W tym przypadku warto wspomnieć o technice umieszczania warunkowych breakpoints:
f1 <- function(dane){
  print('krok 1')
  if(!is.data.frame(dane)) browser()
  model <- lm(price ~ ., data = dane)
  print('krok 1')
  print('krok 2')
  if(TRUE){
    w <- c(1,2)
    y <- 'a'
    z <- 'f'
  }
  summary(model)
}  

f1(diamonds)
f1(diamonds1)

# b. Przy użyciu funkcji debug() oraz debugonce():

# b1. Debugowanie za każdym razem:

debug(f1) # oflagowanie funkcji jako funkcji do debugowania:
f1(diamonds)
f1(diamonds)
undebug(f1) # wyłączanie debugowania

# b2. Debugowanie tylko raz
debugonce(f1)
f1(diamonds)
f1(diamonds)

# c. Debugowanie w przypadku wystąpienia błędu (Error breakpoints)
# Domyślnie RStudio nie wywołuje debuggera, jeśli uzna że przyczyny błędu nie 
# wynikają bezpośrednio z naszego kodu, np.:

lm(price ~ ., data = diamonds1)

# Ale:
f <- function() lm(price ~ ., data = diamonds1)
f()

#Zwróć uwagę że możesz zmienić tryb z debugera na nieco ogólniejszy: 
# Debug -> On Error -> Error Inspector, wtedy:
f()

# Jeśli chcemy, aby każdy błąd powodował otwarcie debuggera, możemy wybrać z Menu:
# Tools -> Global Options następnie odznaczamy opcję 
# “Use debug error handler only when my code contains errors”

# Wtedy:
lm(price ~ ., data = diamonds1)

# Można również ustawić na stałe:
# options(error = browser())
# 
# ALE ZDECYDOWANIE TEGO NIE POLECAMY.


# Wróćmy do funkcji f1(), wywołajmy jakiś błąd:
f1(diamonds1)

# Zauważmy, że okno traceback pozwala nam podróżować pomiędzy środowiskami kolejno
# wywoływanych funkcji i oglądać aktualne wartości parametrów lub obiektów do nich przypisanych.