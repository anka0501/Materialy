f1 <- function(dane){
  print('krok 1')
  model <- lm(price ~ ., data = dane)
  print('krok 1')
  print('krok 2')
  if(TRUE){
    w <- c(1,2)
    y <- 'a'
    z <- 'f'
  }
  summary(model)
}